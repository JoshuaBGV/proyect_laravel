@extends('layouts.dashly')
@section('title', $title)
@section('content')
    <livewire:user.history.withdraw-history />
@endsection
