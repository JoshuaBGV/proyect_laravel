@extends('layouts.app')
@section('content')
    <livewire:admin.trade-settings />
@endsection
