@extends('layouts.app')
@section('content')
    <livewire:admin.mam.master-account-setup />
@endsection
