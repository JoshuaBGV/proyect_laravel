@extends('layouts.app')
@section('content')
    <livewire:admin.deposit.manage-deposit />
@endsection
