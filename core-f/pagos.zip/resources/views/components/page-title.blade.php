<div class="mt-2 mb-1">
    <h1 class="title1">
        {{ $slot }}
    </h1>
</div>
