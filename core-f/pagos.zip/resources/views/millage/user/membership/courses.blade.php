@extends('layouts.millage')
@section('title', $title)
@section('content')
    <livewire:user.system-courses />
@endsection
