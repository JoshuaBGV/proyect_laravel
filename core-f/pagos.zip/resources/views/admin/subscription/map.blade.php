@extends('layouts.app')
@section('content')
    <livewire:admin.mam.symbol-mapping />
@endsection
