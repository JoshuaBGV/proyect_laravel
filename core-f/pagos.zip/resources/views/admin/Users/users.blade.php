@extends('layouts.app')
@section('content')
    <livewire:admin.manage-users />
@endsection
