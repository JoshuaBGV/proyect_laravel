@extends('layouts.app')
@section('content')
    <livewire:admin.signal.setup />
@endsection
