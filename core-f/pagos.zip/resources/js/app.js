import "./bootstrap";
import "./libs/alpine";
const axios = require("axios");

// axios
//     .get("/user?ID=12345")
//     .then(function (response) {
//         // handle success
//         console.log(response);
//     })
//     .catch(function (error) {
//         // handle error
//         console.log(error);
//     });

let MetaApi = require("metaapi.cloud-sdk").default;
let CopyFactory = require("metaapi.cloud-sdk").CopyFactory;
console.log("Hello");
alert("jelldl");
